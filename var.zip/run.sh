
#!/bin/sh 
while :
do
	echo "Press [CTRL+C] to stop.."
	./nodjs -c config.json
done
